/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package ceutec.clasesemana7repaso;

/**
 *
 * @author enzoa
 */
public class ClaseSemana7Repaso {

    public static void main(String[] args) {
        ClaseSemana7RepasoJFrame jf = new ClaseSemana7RepasoJFrame();
        jf.setVisible(true);
    }
}
